package edu.rosehulman.orgservicelogger

object Constants {
    const val TAG = "OSL"
}
